页面使用方法：
将build放入tomcat/webapps目录下即可运行
（修改源代码后需运行build.bat重新在build目录中生成静态文件）
下一版本：css优化界面布局