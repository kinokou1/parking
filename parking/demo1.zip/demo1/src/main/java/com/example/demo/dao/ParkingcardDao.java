package com.example.demo.dao;

import com.example.demo.entity.Parkingcard;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ParkingcardDao {

    @Select("SELECT * FROM parkingcard")
    List<Parkingcard> findAll();

    @Insert("INSERT INTO parkingcard (card_id,card_type,balance,id) values (#{card_id},#{card_type},#{balance},#{id})")
    void insert(Parkingcard parkingcard);

    @Update("UPDATE parkingcard set card_type=#{card_type},balance=#{balance},id=#{id} WHERE card_id=#{card_id}")
    void update(Parkingcard parkingcard);

    @Delete("DELETE FROM parkingcard WHERE card_id=#{card_id}")
    void delete(Parkingcard parkingcard);
}
