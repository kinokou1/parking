/*
package com.example.demo.entity;



public class Instructor {
    private String id;
    private String name;
    private String deptname;
    private float salary;

    public Instructor(String id, String name, String deptname, float salary) {
        this.id = id;
        this.name = name;
        this.deptname = deptname;
        this.salary = salary;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDeptname() {
        return deptname;
    }

    public void setDeptname(String deptname) {
        this.deptname = deptname;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }
}

 */

