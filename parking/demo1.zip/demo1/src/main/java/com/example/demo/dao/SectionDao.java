/*
package com.example.demo.dao;

import com.example.demo.entity.Instructor;
import com.example.demo.entity.Section;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SectionDao {
    List<Section> findSectionsTaughtByInstructor(String instructorId);
}

 */


