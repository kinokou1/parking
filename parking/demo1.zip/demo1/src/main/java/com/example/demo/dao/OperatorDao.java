package com.example.demo.dao;

import com.example.demo.entity.Operator;
import org.apache.ibatis.annotations.*;

import java.util.List;
@Mapper
public interface OperatorDao {

    @Select("SELECT * FROM operator")
    List<Operator> findAll();

    @Insert("INSERT INTO operator (id,name,sex,age) values (#{id},#{name},#{sex},#{age})")
    void insert(Operator operator);

    @Update("UPDATE operator set name=#{name},sex=#{sex},age=#{age} WHERE id=#{id}")
    void update(Operator operator);

    @Delete("DELETE FROM operator WHERE id=#{id}")
    void delete(Operator operator);
}
