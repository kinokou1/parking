/*
package com.example.demo.dao;

import com.example.demo.entity.Instructor;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface InstructorDao {
    List<Instructor> findAllInstructors();

    int insertInstructor(Instructor instructor);

    int updateInstructor(Instructor instructor);

    int deleteInstructor(Instructor instructor);

}

 */

