package com.example.demo.entity;

import lombok.Data;

@Data
public class Parkingcard {

    private String card_id;
    private String card_type;
    private float balance;
    private String id;
}
