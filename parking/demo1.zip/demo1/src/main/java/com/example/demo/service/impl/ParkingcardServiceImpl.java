package com.example.demo.service.impl;

import com.example.demo.dao.ParkingcardDao;
import com.example.demo.entity.Parkingcard;
import com.example.demo.service.IParkingcardService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ParkingcardServiceImpl implements IParkingcardService {

    @Resource
    private ParkingcardDao parkingcardDao;

    @Override
    public List<Parkingcard> findAll() {
        return parkingcardDao.findAll();
    }

    @Override
    public void insert(Parkingcard parkingcard) {
        parkingcardDao.insert(parkingcard);
    }

    @Override
    public void update(Parkingcard parkingcard) {
        parkingcardDao.update(parkingcard);
    }

    @Override
    public void delete(Parkingcard parkingcard) {
        parkingcardDao.delete(parkingcard);
    }
}
