/*
package com.example.demo.entity;

import lombok.Data;

@Data
public class Section {
    String courseId;
    String secId;
    String semester;
    int year;
    String building;
    String roomNumber;
    String timeSlotId;

}

 */


