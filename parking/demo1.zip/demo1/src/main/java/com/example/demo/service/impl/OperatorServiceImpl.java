package com.example.demo.service.impl;

import com.example.demo.dao.OperatorDao;
import com.example.demo.entity.Operator;
import com.example.demo.service.IOperatorService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class OperatorServiceImpl implements IOperatorService {
    @Resource
    private OperatorDao operatorDao;
    @Override
    public List<Operator> findAll() {
        return operatorDao.findAll();
    }

    @Override
    public void insert(Operator operator) {
        operatorDao.insert(operator);
    }

    @Override
    public void update(Operator operator) {
        operatorDao.update(operator);
    }

    @Override
    public void delete(Operator operator) {
        operatorDao.delete(operator);
    }
}
