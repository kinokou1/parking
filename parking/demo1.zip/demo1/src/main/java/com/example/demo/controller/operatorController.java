package com.example.demo.controller;

import com.example.demo.entity.Garage;
import com.example.demo.entity.Operator;
import com.example.demo.service.impl.OperatorServiceImpl;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/operator")
public class operatorController {
    @Autowired
    JdbcTemplate jdbcTemplate;

    @Resource
    private OperatorServiceImpl operatorService;

    @GetMapping("/findAll")
    public List<Operator> findAll() {
        return operatorService.findAll();
    }

    @PostMapping("/insert")
    public Boolean insert(@RequestBody Operator operator) {
        operatorService.insert(operator);
        return true;
    }

    @PutMapping("/update")
    public Boolean update(@RequestBody Operator operator) {
        operatorService.update(operator);
        return true;
    }

    @DeleteMapping("/delete")
    public Boolean delete(@RequestBody Operator operator) {
        operatorService.delete(operator);
        return true;
    }

}
