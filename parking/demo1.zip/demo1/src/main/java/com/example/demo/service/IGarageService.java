package com.example.demo.service;

import com.example.demo.entity.Garage;

import java.util.List;

public interface IGarageService {
    List<Garage> findAll();

    void insert(Garage garage);

    void update(Garage garage);

    void delete(Garage garage);

    //void delete(Integer[] ids);
}
