package com.example.demo.entity;

import lombok.Data;

@Data
public class Garage {

    private String parkingspace_id;

    private Integer total_number;

    private Integer remain_number;

    private String id;
}
