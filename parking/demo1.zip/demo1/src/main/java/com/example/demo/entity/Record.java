package com.example.demo.entity;

import lombok.Data;

import java.time.LocalDate;

@Data
public class Record {
    private String record_no;
    private LocalDate timein;
    private LocalDate timeout;
    private int timetotal;
    private String cost;
    private String vehicle_no;
}
