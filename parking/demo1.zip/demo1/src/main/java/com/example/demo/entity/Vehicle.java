package com.example.demo.entity;

import lombok.Data;

import java.time.LocalDate;

@Data
public class Vehicle {
    private String vehicle_no;
    private LocalDate timein;
    private String card_id;
}
