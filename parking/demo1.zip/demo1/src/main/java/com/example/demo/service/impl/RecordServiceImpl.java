package com.example.demo.service.impl;

import com.example.demo.dao.RecordDao;
import com.example.demo.entity.Record;
import com.example.demo.service.IRecordService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecordServiceImpl implements IRecordService {
    @Resource
    private RecordDao recordDao;

    @Override
    public List<Record> findAll() {
        return recordDao.findAll();
    }

    @Override
    public void insert(Record record) {
        recordDao.insert(record);
    }

    @Override
    public void update(Record record) {
        recordDao.update(record);
    }

    @Override
    public void delete(Record record) {
        recordDao.delete(record);
    }
}
