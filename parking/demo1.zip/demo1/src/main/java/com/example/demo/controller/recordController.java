package com.example.demo.controller;

import com.example.demo.entity.Record;
import com.example.demo.entity.Vehicle;
import com.example.demo.service.impl.RecordServiceImpl;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/record")
public class recordController {
    @Autowired
    JdbcTemplate jdbcTemplate;

    @Resource
    private RecordServiceImpl recordService;

    @GetMapping("/findAll")
    public List<Record> findAll() {
        return recordService.findAll();
    }

    @PostMapping("/insert")
    public Boolean insert(@RequestBody Record record) {
        recordService.insert(record);
        return true;
    }

    @PutMapping("/update")
    public Boolean update(@RequestBody Record record) {
        recordService.update(record);
        return true;
    }

    @DeleteMapping("/delete")
    public Boolean delete(@RequestBody Record record) {
        recordService.delete(record);
        return true;
    }


}
