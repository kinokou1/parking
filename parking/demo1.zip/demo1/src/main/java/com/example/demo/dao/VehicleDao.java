package com.example.demo.dao;

import com.example.demo.entity.Vehicle;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface VehicleDao {

    @Select("SELECT * FROM vehicle")
    List<Vehicle> findAll();

    @Insert("INSERT INTO vehicle (vehicle_no,timein,card_id) values (#{vehicle_no},#{timein},#{card_id})")
    void insert(Vehicle vehicle);

    @Update("UPDATE vehicle set timein=#{timein},card_id=#{card_id} WHERE vehicle_no=#{vehicle_no}")
    void update(Vehicle vehicle);

    @Delete("DELETE FROM vehicle WHERE vehicle_no=#{vehicle_no}")
    void delete(Vehicle vehicle);
}
