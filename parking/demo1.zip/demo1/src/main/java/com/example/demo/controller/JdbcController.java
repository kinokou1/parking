/*
package com.example.demo.controller;

import com.example.demo.dao.InstructorDao;
import com.example.demo.entity.Instructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@RestController
public class JdbcController {
    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    InstructorDao instructorDao;

    @GetMapping("/query")
    public List query() {
        List<Map<String, Object>> list = jdbcTemplate.queryForList("select * from instructor");
        return list;
    }
    @GetMapping("insert")
    public String insert(String id, String name, String deptname, float salary) {
        if ((Objects.isNull(id) || id.isEmpty()) || (Objects.isNull(name) || name.isEmpty()) ||Objects.isNull(deptname) ||salary<0){
            return "Parameter ERROR!";
        }
        jdbcTemplate.execute("insert into instructor(id, name, deptname, salary) values('" + id + "','" + name + "','" + deptname + "'," + salary + ")");
        System.out.println("Ok!");
        String s = "SQL INSERT execute finished!";
        return s;
    }

    @GetMapping("/instructor/findAllInstructors")
    public List<Instructor> findAllInstructors() {
        List<Instructor> allInstructors = instructorDao.findAllInstructors();
        return allInstructors;
    }
    @GetMapping("/instructor/insertInstructor")
    public int insertInstructor(Instructor instructor) {

        return 0;
    }

}
*/