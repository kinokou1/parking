package com.example.demo.service;

import com.example.demo.entity.Vehicle;

import java.util.List;

public interface IVehicleService {
    List<Vehicle> findAll();

    void insert(Vehicle vehicle);

    void update(Vehicle vehicle);

    void delete(Vehicle vehicle);
}
