package com.example.demo.controller;

import com.example.demo.entity.Operator;
import com.example.demo.entity.Parkingcard;
import com.example.demo.service.impl.OperatorServiceImpl;
import com.example.demo.service.impl.ParkingcardServiceImpl;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/parkingcard")
public class parkingcardController {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Resource
    private ParkingcardServiceImpl parkingcardService;

    @GetMapping("/findAll")
    public List<Parkingcard> findAll() {
        return parkingcardService.findAll();
    }

    @PostMapping("/insert")
    public Boolean insert(@RequestBody Parkingcard parkingcard) {
        parkingcardService.insert(parkingcard);
        return true;
    }

    @PutMapping("/update")
    public Boolean update(@RequestBody Parkingcard parkingcard) {
        parkingcardService.update(parkingcard);
        return true;
    }

    @DeleteMapping("/delete")
    public Boolean delete(@RequestBody Parkingcard parkingcard) {
        parkingcardService.delete(parkingcard);
        return true;
    }



}
