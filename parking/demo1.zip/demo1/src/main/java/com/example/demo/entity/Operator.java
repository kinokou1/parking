package com.example.demo.entity;

import lombok.Data;

@Data
public class Operator {
    private String id;
    private String name;
    private String sex;
    private Integer age;
}
