package com.example.demo.service.impl;

import com.example.demo.dao.VehicleDao;
import com.example.demo.entity.Vehicle;
import com.example.demo.service.IVehicleService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehicleServiceImpl implements IVehicleService {
    @Resource
    private VehicleDao vehicleDao;

    @Override
    public List<Vehicle> findAll() {
        return vehicleDao.findAll();
    }

    @Override
    public void insert(Vehicle vehicle) {
        vehicleDao.insert(vehicle);
    }

    @Override
    public void update(Vehicle vehicle) {
        vehicleDao.update(vehicle);
    }

    @Override
    public void delete(Vehicle vehicle) {
        vehicleDao.delete(vehicle);
    }
}
