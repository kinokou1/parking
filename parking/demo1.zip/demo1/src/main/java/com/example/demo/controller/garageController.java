package com.example.demo.controller;

import com.example.demo.entity.Garage;
import com.example.demo.service.impl.GarageServiceImpl;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
@RestController
@RequestMapping("/garage")//给当前控制器下的所有接口添加garage前缀
public class garageController {
    @Autowired
    JdbcTemplate jdbcTemplate;

    @GetMapping("/query")
    public List query() {
        List<Map<String, Object>> list = jdbcTemplate.queryForList("select * from garage");
        return list;

    }
    @Resource
    private GarageServiceImpl garageService;
    @GetMapping("/findAll")
    public List<Garage> findAll() {
        return garageService.findAll();

    }
    @PostMapping("/insert")
    public Boolean insert(@RequestBody Garage garage) {
        garageService.insert(garage);
        return true;
    }

    @PutMapping("/update")
    public Boolean update(@RequestBody Garage garage) {
        garageService.update(garage);
        return true;
    }
    @DeleteMapping("/delete")
    public Boolean delete(@RequestBody Garage garage) {
        garageService.delete(garage);
        return true;
    }
}
