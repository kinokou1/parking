package com.example.demo.service.impl;

import com.example.demo.dao.GarageDao;
import com.example.demo.entity.Garage;
import com.example.demo.service.IGarageService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class GarageServiceImpl implements IGarageService {

    @Resource
    private GarageDao garageDao;

    @Override
    public List<Garage> findAll() {
        return garageDao.findAll();
    }

    @Override
    public void insert(Garage garage) {
        garageDao.insert(garage);
        return;
    }

    @Override
    public void update(Garage garage) {
        garageDao.update(garage);
    }

    @Override
    public void delete(Garage garage) {
        garageDao.delete(garage);
    }


}
