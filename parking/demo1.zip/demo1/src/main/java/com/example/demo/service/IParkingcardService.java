package com.example.demo.service;

import com.example.demo.entity.Parkingcard;

import java.util.List;

public interface IParkingcardService {
    List<Parkingcard> findAll();

    void insert(Parkingcard parkingcard);

    void update(Parkingcard parkingcard);

    void delete(Parkingcard parkingcard);
}
