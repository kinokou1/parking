package com.example.demo.service;

import com.example.demo.entity.Operator;

import java.util.List;

public interface IOperatorService {
    List<Operator> findAll();

    void insert(Operator operator);

    void update(Operator operator);

    void delete(Operator operator);
}
