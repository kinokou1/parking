package com.example.demo.controller;

import com.example.demo.entity.Parkingcard;
import com.example.demo.entity.Vehicle;
import com.example.demo.service.impl.VehicleServiceImpl;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/vehicle")
public class vehicleController {
    @Autowired
    JdbcTemplate jdbcTemplate;

    @Resource
    private VehicleServiceImpl vehicleService;

    @GetMapping("/findAll")
    public List<Vehicle> findAll() {
        return vehicleService.findAll();
    }

    @PostMapping("/insert")
    public Boolean insert(@RequestBody Vehicle vehicle) {
        vehicleService.insert(vehicle);
        return true;
    }

    @PutMapping("/update")
    public Boolean update(@RequestBody Vehicle vehicle) {
        vehicleService.update(vehicle);
        return true;
    }

    @DeleteMapping("/delete")
    public Boolean delete(@RequestBody Vehicle vehicle) {
        vehicleService.delete(vehicle);
        return true;
    }


}
