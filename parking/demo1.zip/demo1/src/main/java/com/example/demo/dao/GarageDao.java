package com.example.demo.dao;

import com.example.demo.entity.Garage;
import org.apache.ibatis.annotations.*;

import java.util.List;
@Mapper
public interface GarageDao {

    @Select("SELECT * FROM garage")
    List<Garage> findAll();
    @Insert("INSERT INTO garage (parkingspace_id,total_number,remain_number,id) values (#{parkingspace_id},#{total_number},#{remain_number},#{id})")
    void insert(Garage garage);
    @Update("UPDATE garage set total_number=#{total_number},remain_number=#{remain_number},id=#{id} WHERE parkingspace_id=#{parkingspace_id}")
    void update(Garage garage);
    @Delete("DELETE FROM garage WHERE parkingspace_id=#{parkingspace_id}")
    void delete(Garage garage);
}
