package com.example.demo.dao;

import com.example.demo.entity.Record;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface RecordDao {

    @Select("SELECT * FROM record")
    List<Record> findAll();

    @Insert("INSERT INTO record (record_no,timein,timeout,timetotal,cost,vehicle_no) values (#{record_no},#{timein},#{timeout},#{timetotal},#{cost},#{vehicle_no})")
    void insert(Record record);

    @Update("UPDATE record set timein=#{timein},timeout=#{timeout},timetotal=#{timetotal},cost=#{cost},vehicle_no=#{vehicle_no} WHERE record_no=#{record_no}")
    void update(Record record);

    @Delete("DELETE FROM record WHERE record_no=#{record_no}")
    void delete(Record record);
}
