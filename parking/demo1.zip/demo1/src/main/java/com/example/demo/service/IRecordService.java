package com.example.demo.service;

import com.example.demo.entity.Record;

import java.util.List;

public interface IRecordService {
    List<Record> findAll();

    void insert(Record record);

    void update(Record record);

    void delete(Record record);
}
